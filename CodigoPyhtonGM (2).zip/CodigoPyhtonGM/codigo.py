#Então de acordo com  o que a gente conversou eu pensei em juntar python com banco de dados pra ter 1 pouco de tudo no codigo 
import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
# Criação da conexao com banco 
conn=sqlite3.connect("vendas.db")
cursor=conn.cursor()
# Criei uma tabela fictia pra simular os dados 
cursor.execute('''
    CREATE TABLE IF NOT EXISTS vendas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        produto TEXT,
        valor REAL,
        quantidade INTEGER,
        data TEXT,
        UNIQUE(produto, valor, quantidade, data)
    )
''')

conn.commit()
#Função pra não acontecer duplicata de dados 
cursor.execute("DELETE FROM vendas")
conn.commit()

# Aqui eu inseri esses dados fictícios no SQL 
cursor.executemany(
    "INSERT INTO vendas (produto, valor, quantidade, data) VALUES (?, ?, ?, ?)",
    [
        ("Notebook", 3500.00, 2, "2025-03-01"),
        ("Mouse", 150.00, 5, "2025-03-02"),
        ("Teclado", 200.00, 3, "2025-03-02"),
        ("Monitor", 1200.00, 1, "2025-03-03"),
        ("Cadeira", 900.00, 2, "2025-03-04")
    ]
)

conn.commit()

# Consulta SQL 
query = "SELECT * FROM vendas"
df = pd.read_sql_query(query, conn)
print("Dados do banco de Dados")
print(df)

# Calculei a media do valor desses produtos 
media_valor=df["valor"].mean()
print(f"\n Média de valor dos produtos vendidos: R${media_valor:.2f}")

#Salvei todos esses dados em um arquivo CSV
df.to_csv("relatorio_vendas.csv", index=False)
print(f"\n Relatorio salvo como 'relatorio_vendas.csv'")

# Criei um gráfico de vendascom todos os dados 
plt.figure(figsize=(8,5))
plt.bar(df["produto"],df["valor"],color = "skyblue")
plt.xlabel("Produto")
plt.ylabel("Valor (R$)")
plt.title("Valor das vendas por Produto")
plt.xticks(rotation=45)
plt.show()

#Fechamento da Conexão de dados 
conn.close()
cursor.close()